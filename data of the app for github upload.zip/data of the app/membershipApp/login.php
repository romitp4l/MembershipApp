<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "membershipapp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// echo "test successful ";


// Check if the data is sent via POST
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you're sending 'mobileNo' parameter from Android
    $mobileNo = $_POST['mobileNo'];
    $password =$_POST['password'];
    //  $mobileNo = "8888888888";
    //  $password= "jdhieiheih";

    // // SQL query to check if the mobile number exists in the database
    // $checkSql = "SELECT * FROM 'login' WHERE 'mobileNo' = '$mobileNo'";
    // $checkResult = $conn->query($checkSql);
    // // var_dump($checkResult);exit;

    // if ($checkResult->num_rows > 0) {
    //     // Mobile number already exists in the database
    //     echo json_encode(array('status' => true ));
    // } else {
    //     // Mobile number does not exist in the database, insert a new record
    //     $insertSql = "INSERT INTO `login` (`serial_no`, `mobileNo`, `password`) VALUES ('', $mobileNo, $password);";
    //     if ($conn->query($insertSql) === TRUE) {
    //         echo json_encode(array('status' => true));
    //     } else {
    //         echo json_encode(array('status' => false . $conn->error));
    //     }
    // }

//---------------


 // Mobile number does not exist in the database, insert a new record
 $insertSql = "INSERT INTO `login` (`serial_no`, `mobileNo`, `password`) VALUES ('', '$mobileNo',' $password');";
 if ($conn->query($insertSql) === TRUE) {
     echo json_encode(array('status' => "true"));
    //return true;
 } else {
     echo json_encode(array('status' => false . $conn->error));
    // return false;
 }

 //-------------------------

// }

$conn->close();
?>
