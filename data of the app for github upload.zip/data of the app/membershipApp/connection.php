<?php
$db_name = "membershipapp";
$mysql_username = "root";
$mysql_password = "";
$server_name ="localhost";

$con = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);
if($con){
    echo"connection success ";
}else{
    echo"connection not successful";
}
?>