<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "membershipapp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming you're sending 'mobileNo' parameter from Android
$mobileNo = $_POST['mobileNo'];
// $mobileNo = '905255435';

// SQL query to fetch data from the table
$sql = "SELECT mobileNo, password FROM `login` WHERE mobileNo = '$mobileNo'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetching data as an associative array
    $row = $result->fetch_assoc();

    // Sending JSON response with mobileNo and password
    echo json_encode(array('status' => true, 'mobileNo' => $row['mobileNo'], 'password' => $row['password']));
} else {
    // No data found in the table
    echo json_encode(array('status' => false, 'message' => 'No data found for the provided mobileNo.'));
}

$conn->close();
