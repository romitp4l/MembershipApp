<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "membershipapp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// echo "test successful ";


// Check if the data is sent via POST
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you're sending 'mobileNo' parameter from Android
    $mobileNo = $_POST['mobileNo'];
    // $mobileNo = '8888888888';

    // SQL query to check if the mobile number exists in the database
    $checkSql = "SELECT * FROM checkuser WHERE mobile_mobileNo = '$mobileNo'";
    $checkResult = $conn->query($checkSql);
    // var_dump($checkResult);exit;

    if ($checkResult->num_rows > 0) {
        // Mobile number already exists in the database
        echo json_encode(array('status' => true, 'message' => 'Mobile number already exists.'));
    } else {
        // Mobile number does not exist in the database, insert a new record
        $insertSql = "INSERT INTO `checkuser` (`mobile_mobileNo`) VALUES ($mobileNo)";
        if ($conn->query($insertSql) === TRUE) {
            echo json_encode(array('status' => true, 'message' => 'Mobile number saved successfully.'));
        } else {
            echo json_encode(array('status' => false, 'message' => 'Error saving mobile number: ' . $conn->error));
        }
    }
// }

$conn->close();
?>
