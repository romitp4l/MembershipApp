<?php 

echo"<h1>  welcome to romitp4l windows server </h1> "

?>