-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2023 at 07:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `membershipapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkmembership`
--

CREATE TABLE `checkmembership` (
  `phoneNo` bigint(10) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkmembership`
--

INSERT INTO `checkmembership` (`phoneNo`, `password`) VALUES
(9999999999, '9999999999');

-- --------------------------------------------------------

--
-- Table structure for table `checkuser`
--

CREATE TABLE `checkuser` (
  `sn` int(10) NOT NULL,
  `mobile_mobileNo` bigint(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkuser`
--

INSERT INTO `checkuser` (`sn`, `mobile_mobileNo`) VALUES
(1, 6386745752),
(2, 8888888888),
(3, 9090909090),
(4, 65757656567),
(5, 465464),
(6, 0),
(7, 9621743546),
(8, 9005255435);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `serial_no` int(11) NOT NULL,
  `mobileNo` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`serial_no`, `mobileNo`, `password`) VALUES
(1, '6385745752', 'Qwer123@#'),
(3, '905255435', 'Qwer123@#'),
(5, '6321743732', ' testing'),
(6, '7084133024', ' thvcfghh'),
(7, '9198806740', ' ddsffg'),
(8, '636635255', ' hyhgyyhy'),
(9, '9005255435', ' Qwer123@#'),
(10, '5465858468264', ' gsihshsjs'),
(11, '8549664948', ' fskshsiis');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkmembership`
--
ALTER TABLE `checkmembership`
  ADD PRIMARY KEY (`phoneNo`);

--
-- Indexes for table `checkuser`
--
ALTER TABLE `checkuser`
  ADD PRIMARY KEY (`sn`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`serial_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `checkuser`
--
ALTER TABLE `checkuser`
  MODIFY `sn` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `serial_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
